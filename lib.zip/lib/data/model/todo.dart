import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';
// Создаем модель Todo
class Todo extends Equatable {
  final String id;
  final String title;
  final String description;
  final DateTime createdAt;
  final bool isCompleted;
  // Делаем конструктор этого класса
  Todo({
    String? id,
    required this.title,
    this.description = '',
    DateTime? createdAt,
    this.isCompleted = false,
  }) : 
  id = id ?? const Uuid().v4(), // если у нас есть id то используем его а если нет то генерируем его
  createdAt = createdAt ?? DateTime.now(); // если у нас есть createdAt то используем его а если нету то получаем настоящее время
// Применяем новую функцию copyWith
  Todo copyWith({
    String? title,
    String? description,
    bool? isCompleted,
  }) {
    return Todo(
      id: id,
      title: title ?? this.title,
      description: description ?? this.description,
      createdAt: createdAt,
      isCompleted: isCompleted ?? this.isCompleted 
    );
  }
// Закидываем все данные в Json
  Map<String, dynamic> toJson () {
    return {
      'id': id,
      'title': title,
      'description': description,
      'createdAt': createdAt.toIso8601String(), // формат времени
      'isCompleted': isCompleted
    };
  }
  //Обращаемся к ним из Jsona
  static Todo fromJson (Map<String, dynamic> json) {
    return Todo(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      isCompleted: json['isCompleted'] as bool,
    );
  }

  @override
  List<Object?> get props => [
    id,
    title,
    description,
    createdAt,
    isCompleted,
  ];
}