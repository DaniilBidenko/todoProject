import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:to_do/bloc/todo_bloc.dart';
import 'package:to_do/bloc/todo_event.dart';
import 'package:to_do/data/model/todo.dart';

class AddTodoScreen extends StatefulWidget{
  const AddTodoScreen({Key? key}) : super (key: key); 
  @override
  _AddTodoScreenState createState() => _AddTodoScreenState(); // создаем состояние 
}

class _AddTodoScreenState extends State<AddTodoScreen> {
  final _formKey = GlobalKey<FormState>(); // делаем ключ формы
  final _titleController = TextEditingController(); // делаем переменную которую можем использовать только в этом классе и которая будет сохранять текст
  final _descriptionController = TextEditingController();
  
  @override
  void dispose () { // функция очистки контроллеров при удалении виджета
    _titleController.dispose(); // эта строчка очищает текст заголовка
    _descriptionController.dispose(); // это строчка очищает текст описания
    super.dispose();
  }

  

  @override // создаем экран
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Добавление задач'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16), // делаем отступ со всех сторон 16 пикселей
        child: Form( // Form используется для валедации полей 
          key: _formKey, // исользуем наш ключ
          child: Column(
            children: [
              TextFormField(
                controller: _titleController, // исользуем нашу переменную для сохранения заголовка
                decoration: InputDecoration(
                  labelText: 'Заголовок',
                  border: OutlineInputBorder()
                ),
              ),
              SizedBox(
                height: 16, // отступ между элементами
              ),
              TextFormField(
                controller: _descriptionController, // используем нашу переменную для сохранения описания
                decoration: InputDecoration(
                  labelText: 'Описание',
                  border: OutlineInputBorder()
                ),
              ),
              SizedBox(
                height: 24, // отступ между элементами
              ),
              ElevatedButton(
                onPressed: _submitForm, // при нажатии будет вызываться функция _submitForm
                child: Padding(
                  padding: EdgeInsets.symmetric(
                  vertical: 12,
                  horizontal: 3
                  ),
                  child: Text('Добавить задачу',
                  style: TextStyle(
                    fontSize: 16
                  )
                  ),
                  )
                )
            ],
          )
          ),
        ),
    );
    
  }

  void _submitForm () { 
    if (_formKey.currentState!.validate()) { // если текущее состояние утверждено
      final newTodo = Todo( // делаем обьект нашего класса Todo
       title: _titleController.text, // преобразуем наши переменные в текст
       description: _descriptionController.text,
      );
      
      context.read<TodoBloc>().add(AddTodo(newTodo)); // отправляем наше событие в блок 
      Navigator.pop(context); // возвращение на предыдущий экран
    }
  }

}

